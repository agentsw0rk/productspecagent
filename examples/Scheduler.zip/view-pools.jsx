export function PoolsView() { return <main>Pools</main>; }
