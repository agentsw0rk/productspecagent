export function DesignCanvas({ children }) { return children; }
export function DCSection({ children }) { return children; }
export function DCArtboard({ children }) { return children; }
export function Frame({ children }) { return children; }
